from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from openai import OpenAI

from app.config import REPORTS_DIR

SYSTEM_PROMPT = """
你是一个面向投资新手的金融教育与市场研究助手，不是持牌投资顾问。
你只能根据用户提供的行情数据作解释，不得声称你已经搜索新闻或实时行情。
不要编造事实、数据、宏观事件、新闻来源、概率或目标价。
明确区分：数据事实、可能的解释、未知因素。
不能把均线、RSI 或历史走势当成可靠的未来预测。不得给出确定性的买入、卖出指令。
必须指出本次输入没有包含的关键数据，以及结论的不确定性。
输出简体中文 JSON，结构如下：
{
  "title": "报告标题",
  "data_cutoff": "输入数据的最新日期",
  "plain_language_summary": "给新手看的总体解释",
  "observations": ["有数据支持的观察"],
  "possible_bullish_factors": ["可能的积极因素及其局限"],
  "possible_bearish_factors": ["可能的风险因素及其局限"],
  "what_to_watch": ["后续值得核查的数据或事件"],
  "limitations": ["数据和分析局限"],
  "education_note": "这不是个性化投资建议"
}
""".strip()


def generate_report(ticker: str, summary: dict[str, Any]) -> Path:
    api_key = os.getenv("DEEPSEEK_API_KEY", "").strip()
    if not api_key or api_key == "replace_with_your_deepseek_api_key":
        raise RuntimeError(
            "未配置 DEEPSEEK_API_KEY。请复制 .env.example 为 .env，并填入自己的 API Key。"
        )

    client = OpenAI(
        api_key=api_key,
        base_url=os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
    )
    model = os.getenv("DEEPSEEK_MODEL", "deepseek-flash")
    user_prompt = (
        "请根据以下行情摘要生成 JSON 格式的中文研究报告。不要引入摘要以外的当前新闻或实时事实。"
        "如果某些指标为 null，说明历史数据不足，不要猜数值。\n\n"
        + json.dumps(summary, ensure_ascii=False, indent=2)
    )

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        response_format={"type": "json_object"},
        max_tokens=1800,
        temperature=0.2,
    )
    content = response.choices[0].message.content
    if not content:
        raise RuntimeError("DeepSeek 返回空内容。请稍后重试，或检查模型和 API 额度。")
    try:
        report_data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"DeepSeek 返回的内容不是有效 JSON：{exc}") from exc

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    run_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = REPORTS_DIR / f"{ticker.upper()}_{run_stamp}.md"
    lines = [
        f"# {report_data.get('title', f'{ticker.upper()} 每日研究报告')}",
        "",
        f"- 标的：{ticker.upper()}",
        f"- 行情截止日期：{report_data.get('data_cutoff', summary['latest_date'])}",
        f"- 生成时间：{datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"- 模型：{model}",
        "- 数据来源：yfinance / Yahoo Finance 公开行情接口",
        "",
        "> 本报告是基于有限历史数据生成的教育性分析，不构成投资建议。第一版尚未联网搜索新闻，也未接入宏观经济数据。",
        "",
        "## 通俗总结",
        str(report_data.get("plain_language_summary", "暂无")),
        "",
    ]
    sections = [
        ("数据观察", "observations"),
        ("可能的积极因素", "possible_bullish_factors"),
        ("可能的风险因素", "possible_bearish_factors"),
        ("后续值得关注", "what_to_watch"),
        ("局限与不确定性", "limitations"),
    ]
    for title, key in sections:
        lines.extend([f"## {title}", ""])
        values = report_data.get(key, [])
        if isinstance(values, list) and values:
            lines.extend([f"- {item}" for item in values])
        else:
            lines.append("- 暂无")
        lines.append("")
    lines.extend(["## 说明", "", str(report_data.get("education_note", "仅用于金融教育和研究。")), ""])
    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path
