from __future__ import annotations

import yfinance as yf

from app.db import initialize_database, upsert_history


def sync_ticker(ticker: str, period: str = "5y") -> int:
    """Download daily OHLCV and corporate actions for one ticker and save them to SQLite."""
    print(f"[行情同步] 正在下载 {ticker} 的 {period} 日线数据……")
    instrument = yf.Ticker(ticker)
    history = instrument.history(
        period=period,
        interval="1d",
        auto_adjust=False,
        actions=True,
        repair=True,
        raise_errors=True,
    )
    if history.empty:
        raise RuntimeError(
            f"{ticker} 没有返回行情。可能是网络、数据源限制或标的代码问题。"
        )

    initialize_database()
    saved = upsert_history(ticker, history)
    latest_date = history.index[-1].date().isoformat()
    print(f"[完成] {ticker}: 本次写入/更新 {saved} 条记录，最新行情日期 {latest_date}")
    return saved
